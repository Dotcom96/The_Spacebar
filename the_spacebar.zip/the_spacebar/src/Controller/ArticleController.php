<?php

namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Michelf\MarkdownInterface;
use Symfony\Component\Cache\Adapter\AdapterInterface;

class ArticleController extends AbstractController {

  /**
   * @Route("/", name="app_homepage")
   */

  public function homepage() {
    return $this->render('article/homepage.html.twig');
  }

/**
 * @Route("/news/{slug}", name="article_show")
 */

  public function show($slug, MarkdownInterface $markdown, AdapterInterface $cache) {

    $comments = [
      'Listicle occupy meggings, palo santo austin adipisicing banjo sartorial single-origin coffee leggings ut slow-carb gochujang.',
      '8-bit messenger bag green juice, roof party irure venmo next level authentic taxidermy.',
    ];

    $articleContent = <<<EOF
Lorem ipsum dolor amet squid adaptogen **fam microdosing** occupy four dollar toast succulents selfies tofu poutine swag tacos hella. Sustainable tousled shoreditch tattooed. Before they sold out everyday carry unicorn yuccie twee intelligentsia selfies cornhole XOXO hashtag truffaut. Listicle four loko beard, tofu art party enamel pin small batch fam chambray offal pinterest four dollar toast truffaut.

Plaid deep v cornhole godard. Subway tile occupy [microdosing activated charcoal](https://hipsum.co/), godard selfies tumblr brunch knausgaard. Poutine aesthetic put a bird on it meditation meggings enamel pin, chartreuse pinterest selvage truffaut organic ennui biodiesel. Narwhal microdosing waistcoat hashtag schlitz single-origin coffee heirloom everyday carry lomo mixtape gastropub.

Enamel pin pop-up schlitz migas **air plant**. Keytar master cleanse cliche 8-bit fam bicycle rights brunch. Tattooed lumbersexual beard chartreuse trust fund chillwave, cliche pug typewriter 3 wolf moon try-hard asymmetrical. Authentic squid cloud bread plaid vinyl yr intelligentsia hell of food truck. Bushwick tumblr chambray keffiyeh banh mi snackwave ethical banjo. Brunch cred ramps tofu, mlkshk marfa franzen +1 bespoke trust fund pour-over live-edge. Intelligentsia gentrify flexitarian jianbing locavore chambray.
EOF;

    $item = $cache->getItem('$markdown_'.md5($articleContent));
    if (!$item->isHit()) {
        $item->set($markdown->transform($articleContent));
        $cache->save($item);
    }
    $articleContent = $item->get();

    return $this->render('article/show.html.twig', [
      'title' => ucwords(str_replace('-', ' ', $slug)),
      'articleContent' => $articleContent,
      'slug' => $slug,
      'comments' => $comments,
    ]);
  }

  /**
   * @Route("/news/{slug}/heart", name="article_toggle_heart", methods={"POST"})
   */

  public function toggleArticleHeart($slug) {
    return $this->json(['hearts' => rand(5, 100)]);
  }

}
